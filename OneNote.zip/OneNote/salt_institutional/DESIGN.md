# Design System Documentation

## Theme Overview

This document outlines the core aesthetic principles and design token values that define our digital product's look and feel.

### Color Palette

Our brand colors are derived from a foundation focused on **fidelity**, ensuring a cohesive and professional appearance in a **light** mode context.

*   **Primary Color:** `#002147` - The cornerstone of our brand, used for key interactive elements and branding.
*   **Secondary Color:** `#4A5568` - A supportive color for less prominent UI components and secondary actions.
*   **Tertiary Color:** `#38A169` - An accent color for highlights, badges, or decorative elements, providing visual interest.
*   **Neutral Color:** `#F8F9FA` - The base color for backgrounds, surfaces, and non-chromatic elements, providing a clean canvas.

### Typography

We employ a distinct typographic hierarchy to ensure readability and brand consistency.

*   **Headlines:** `Manrope` - Chosen for its modern and readable qualities, suitable for strong headings.
*   **Body Text:** `Inter` - A highly versatile and legible typeface for all general body copy, ensuring clear communication.
*   **Labels:** `Inter` - Consistent with body text for form labels and smaller UI text, maintaining visual harmony.

### Shape and Form

Our UI elements feature **subtly rounded** corners, offering a balanced and approachable aesthetic without being overly soft or sharp.

### Spacing

We use **normal** spacing throughout the UI, providing a good balance between density and readability, allowing elements appropriate room to breathe.